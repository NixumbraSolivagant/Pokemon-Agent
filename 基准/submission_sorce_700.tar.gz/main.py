"""Kaggle competition entrypoint — Archaludon ex metal-tempo agent.

Architecture: Mirror the official pokemon-steel.ipynb pattern.
- Single file entry point (no agent.py indirection)
- cg/ SDK auto-located from several known paths
- agent() defined in this same file
- deck.csv loaded once at module import time
"""
from __future__ import annotations

import os
import random
import sys
from typing import List

# ── Locate cg/ SDK (Kaggle extracts tarball to /kaggle_simulations/agent) ──────
_cg_candidates: list[str] = []

# 1) Directory of THIS file (in case __file__ is available).
try:
    _here = os.path.dirname(os.path.abspath(__file__))  # type: ignore
    _cg_candidates.append(_here)
except NameError:
    pass

# 2) Walk sys.path (injected by Kaggle's get_last_callable) for cg/.
for sp in sys.path:
    if sp and os.path.isdir(os.path.join(sp, "cg")):
        _cg_candidates.append(sp)

# 3) Kaggle-expected directories and cwd.
_cg_candidates += [
    "/kaggle_simulations/agent",
    "/kaggle/working",
    os.getcwd(),
    ".",
]

_CG_DIR: str | None = None
for p in _cg_candidates:
    if p and os.path.isdir(os.path.join(p, "cg")):
        _CG_DIR = p
        break

if _CG_DIR and _CG_DIR not in sys.path:
    sys.path.insert(0, _CG_DIR)

# ── Import engine bindings (defer failure to agent() so deck selection works) ──
_CG_OK = False
try:
    from cg.api import (  # type: ignore
        AreaType,
        LogType,
        OptionType,
        SelectContext,
        all_card_data,
        to_observation_class,
    )
    _CG_OK = True
except Exception as _e:
    print(f"[PTCG] cg.api import failed: {_e}", file=sys.stderr, flush=True)
    AreaType = LogType = OptionType = SelectContext = None  # type: ignore
    all_card_data = None  # type: ignore
    to_observation_class = None  # type: ignore

try:
    from cg.api import all_attack
    ALL_ATTACKS = {a.attackId: a for a in all_attack()}
except Exception:
    ALL_ATTACKS = {}

# ── Card DB (built once at import) ────────────────────────────────────────────
CARD_DB: dict[int, object] = {}
if _CG_OK:
    try:
        CARD_DB = {c.cardId: c for c in all_card_data()}
    except Exception:
        pass

# ── Deck loading ──────────────────────────────────────────────────────────────
def _read_deck() -> List[int]:
    candidates = ["deck.csv"]
    if _CG_DIR:
        candidates.append(os.path.join(_CG_DIR, "deck.csv"))
    candidates += [
        "/kaggle_simulations/agent/deck.csv",
        "/kaggle/working/deck.csv",
    ]
    for p in candidates:
        if p and os.path.exists(p):
            with open(p) as f:
                lines = [int(l.strip()) for l in f if l.strip()]
            if len(lines) == 60:
                return lines
            if len(lines) > 60:
                return lines[:60]
    # Fallback: 60 Metal Energy — engine will reject invalid IDs
    # but we at least won't crash with a stack trace.
    return [8] * 60


DECK: List[int] = _read_deck()

# ── Card IDs ─────────────────────────────────────────────────────────────────
DURALUDON = 169
ARCHALUDON_EX = 190
CINDERACE = 666
RELICANTH = 57
METAL_ENERGY = 8
POKE_PAD = 1152
ULTRA_BALL = 1121
POKEGEAR = 1122
NIGHT_STRETCHER = 1097
JUMBO_ICE_CREAM = 1147
HERO_CAPE = 1159
BOSS = 1182
EXPLORER = 1185
LILLIE = 1227
FULL_METAL_LAB = 1244
RAGING_HAMMER = 224
METAL_DEFENDER = 253

_ATTACK_BASE_DMG = {METAL_DEFENDER: 220, 965: 50, 223: 30, 61: 30}

_SETUP_ACTIVE_PRIORITY = {
    CINDERACE: (100000, "Active: Cinderace Explosiveness"),
    DURALUDON: (20000, "Active fallback: Duraludon"),
    RELICANTH: (5000, "Active fallback: Relicanth"),
}

_opp_last_attack_id = None
_cur_turn_logs = []


def _update_opp_attack_tracking(obs):
    global _opp_last_attack_id, _cur_turn_logs
    yi = obs.current.yourIndex
    for entry in obs.logs:
        if entry.type == LogType.TURN_END:
            for prev in _cur_turn_logs:
                if prev.type == LogType.ATTACK and getattr(prev, "playerIndex", yi) != yi:
                    _opp_last_attack_id = prev.attackId
            _cur_turn_logs.clear()
        else:
            _cur_turn_logs.append(entry)


# ── Board helpers ─────────────────────────────────────────────────────────────
def _get_card(obs, area, index, player_index):
    if area is None or index is None:
        return None
    ps = obs.current.players[player_index]
    if area == AreaType.DECK and obs.select and obs.select.deck:
        return obs.select.deck[index] if index < len(obs.select.deck) else None
    if area == AreaType.HAND and ps.hand:
        return ps.hand[index] if index < len(ps.hand) else None
    if area == AreaType.DISCARD:
        return ps.discard[index] if index < len(ps.discard) else None
    if area == AreaType.ACTIVE:
        return ps.active[index] if index < len(ps.active) else None
    if area == AreaType.BENCH:
        return ps.bench[index] if index < len(ps.bench) else None
    if area == AreaType.PRIZE:
        return ps.prize[index] if index < len(ps.prize) else None
    if area == AreaType.STADIUM:
        return obs.current.stadium[index] if index < len(obs.current.stadium) else None
    if area == AreaType.LOOKING and obs.current.looking:
        return obs.current.looking[index] if index < len(obs.current.looking) else None
    return None


def _option_card(obs, opt):
    yi = obs.current.yourIndex
    pi = getattr(opt, "playerIndex", None)
    if pi is None:
        pi = yi
    if opt.type == OptionType.PLAY:
        return _get_card(obs, AreaType.HAND, getattr(opt, "index", None), pi)
    return _get_card(obs, getattr(opt, "area", None), getattr(opt, "index", None), pi)


def _option_target(obs, opt):
    ia = getattr(opt, "inPlayArea", None)
    ii = getattr(opt, "inPlayIndex", None)
    if ia is None or ii is None:
        return None
    return _get_card(obs, ia, ii, obs.current.yourIndex)


def _my_state(obs):
    return obs.current.players[obs.current.yourIndex]


def _opp_state(obs):
    return obs.current.players[1 - obs.current.yourIndex]


def _active(obs):
    ps = _my_state(obs)
    return ps.active[0] if ps.active else None


def _opp_active(obs):
    ps = _opp_state(obs)
    return ps.active[0] if ps.active else None


def _all_my_pokemon(obs):
    ps = _my_state(obs)
    return [p for p in (ps.active + ps.bench) if p]


def _hand_ids(obs):
    hand = _my_state(obs).hand
    return [c.id for c in hand if c] if hand else []


def _discard_ids(obs):
    return [c.id for c in (_my_state(obs).discard or []) if c]


def _metal_in_discard(obs):
    return sum(1 for c in (_my_state(obs).discard or []) if c and c.id == METAL_ENERGY)


def _energy_count(pokemon):
    if pokemon is None:
        return 0
    ec = getattr(pokemon, "energyCards", None)
    if ec is not None:
        return len(ec)
    return len(getattr(pokemon, "energies", []) or [])


def _damage_on(pokemon):
    if pokemon is None:
        return 0
    mhp = getattr(pokemon, "maxHp", None)
    return max(0, (mhp or pokemon.hp) - pokemon.hp)


def _has_tool(pokemon):
    return bool(getattr(pokemon, "tools", []) or [])


def _has_in_play(obs, card_id):
    return any(p.id == card_id for p in _all_my_pokemon(obs))


def _retreat_cost(pokemon):
    data = CARD_DB.get(pokemon.id) if pokemon else None
    if data is None:
        return 0
    return getattr(data, "retreatCost", 0)


def _best_attack_damage(obs, attack_id):
    if attack_id == RAGING_HAMMER:
        return 80 + _damage_on(_active(obs)) // 10 * 10
    return _ATTACK_BASE_DMG.get(attack_id, 0)


def _is_metal_weak(pokemon):
    if pokemon is None:
        return False
    data = CARD_DB.get(pokemon.id)
    w = getattr(data, "weakness", None) if data else None
    if w is None:
        return False
    return getattr(w, "value", w) == METAL_ENERGY


def _effective_damage(base, target):
    return base * 2 if _is_metal_weak(target) else base


# ── Attack routes ────────────────────────────────────────────────────────────
def _can_evolve_now(pokemon, obs):
    if pokemon is None or pokemon.id != DURALUDON:
        return False
    if ARCHALUDON_EX not in _hand_ids(obs):
        return False
    return not getattr(pokemon, "appearThisTurn", True)


def _archaludon_attack_route(obs):
    active = _active(obs)
    if active and active.id in {ARCHALUDON_EX, DURALUDON}:
        e = _energy_count(active)
        mc = _metal_in_discard(obs)
        if active.id == ARCHALUDON_EX:
            if e >= 3:
                return {"attacker": active, "uses_attach": False, "needs_retreat": False}
            if e == 2 and not obs.current.energyAttached and METAL_ENERGY in _hand_ids(obs):
                return {"attacker": active, "uses_attach": True, "needs_retreat": False}
        else:  # Duraludon
            if e >= 3:
                return {"attacker": active, "uses_attach": False, "needs_retreat": False}
            if e == 2 and not obs.current.energyAttached and METAL_ENERGY in _hand_ids(obs):
                return {"attacker": active, "uses_attach": True, "needs_retreat": False}
            if _can_evolve_now(active, obs):
                total = e + min(2, mc)
                if total >= 3:
                    return {"attacker": active, "uses_attach": False, "needs_retreat": False}
                if total == 2 and not obs.current.energyAttached and METAL_ENERGY in _hand_ids(obs):
                    return {"attacker": active, "uses_attach": True, "needs_retreat": False}

    if active is None or obs.current.retreated or _energy_count(active) < _retreat_cost(active):
        pass
    else:
        return None

    ps = _my_state(obs)
    for pokemon in [p for p in ps.bench if p]:
        if pokemon.id not in {ARCHALUDON_EX, DURALUDON}:
            continue
        e = _energy_count(pokemon)
        mc = _metal_in_discard(obs)
        if pokemon.id == ARCHALUDON_EX:
            if e >= 3:
                return {"attacker": pokemon, "uses_attach": False, "needs_retreat": True}
        else:
            if e >= 3:
                return {"attacker": pokemon, "uses_attach": False, "needs_retreat": True}
            if _can_evolve_now(pokemon, obs):
                total = e + min(2, mc)
                if total >= 3:
                    return {"attacker": pokemon, "uses_attach": False, "needs_retreat": True}
    return None


# ── Matchup detection ────────────────────────────────────────────────────────
CRUSTLE_LINE = {344, 345, 532}
STARMIE_LINE = {1030, 1031}
LUCARIO_LINE = {677, 678}
HOP_LINE = {288, 289, 299, 304, 307, 308, 309, 310, 878, 879}
HOP_SNORLAX = 304
MEGA_BRAVE = 983
PREMIUM_POWER_PRO = 1141

ALAKAZAM_LINE = {741, 742, 743}
_ALA_BOARD_GAIN = {66: 3, 742: 2, 305: 2, 65: 2, 741: 1}


def _estimate_alakazam_from_pokes(opp, pokes):
    ids = [p.id for p in pokes if p]
    if not (ALAKAZAM_LINE & set(ids)):
        return 0, 0, 0
    base = opp.handCount + 1
    gain = sum(_ALA_BOARD_GAIN.get(i, 0) for i in ids)
    enriching_seen = (
        any(c and c.id == 13 for c in (opp.discard or []))
        or any(
            c and c.id == 13
            for p in pokes
            if p
            for c in (getattr(p, "energyCards", None) or [])
        )
    )
    if not enriching_seen:
        gain += 3
    if 140 in ids:
        gain += 3
    return base * 20, (base + gain + 2) * 20, (base + gain - 1) * 20


def _detect_matchup(obs):
    opp = _opp_state(obs)
    ids = {p.id for p in (opp.active + opp.bench) if p}
    if ids & CRUSTLE_LINE:
        return "crustle"
    if ids & HOP_LINE:
        return "hop"
    if ids & STARMIE_LINE:
        return "starmie"
    if ids & LUCARIO_LINE:
        return "lucario"
    if ids & ALAKAZAM_LINE:
        return "alakazam"
    return "generic"


def _opp_max_damage(obs):
    m = _detect_matchup(obs)
    if m == "alakazam":
        return _estimate_alakazam_from_pokes(_opp_state(obs), [])[1]
    if m == "crustle":
        return 120
    if m == "hop":
        return 220
    if m == "lucario":
        return 270
    if m == "starmie":
        return 210
    return 220


# ── Ice Cream decision ──────────────────────────────────────────────────────
_IC_HP_THRESHOLD = {
    "lucario": 270,
    "starmie": 210,
    "crustle": 120,
    "hop": 220,
    "generic": 230,
}


def _should_skip_ice_cream(obs, active):
    if active.id != ARCHALUDON_EX:
        return True, "not Archaludon ex"
    opp_act = _opp_active(obs)
    if opp_act and _has_in_play(obs, RELICANTH):
        md_kills = _effective_damage(220, opp_act) >= opp_act.hp
        if not md_kills:
            rh = 80 + _damage_on(active) // 10 * 10
            rh_after = 80 + max(0, _damage_on(active) - 80) // 10 * 10
            if _effective_damage(rh, opp_act) >= opp_act.hp and _effective_damage(rh_after, opp_act) < opp_act.hp:
                return True, "healing loses Raging Hammer KO"

    m = _detect_matchup(obs)
    if m == "alakazam":
        floor, ceiling, _ = _estimate_alakazam_from_pokes(_opp_state(obs), [])
        opp_a = _opp_active(obs)
        if opp_a:
            attacks = [{"damage": 220}]
            if any(_effective_damage(a["damage"], opp_a) >= opp_a.hp for a in attacks):
                _, ceiling, _ = _estimate_alakazam_from_pokes(_opp_state(obs), list(_opp_state(obs).bench or []))
        ice_count = sum(1 for c in (_my_state(obs).hand or []) if c and c.id == JUMBO_ICE_CREAM)
        max_hp = getattr(active, "maxHp", active.hp)
        hp_after = min(max_hp, active.hp + ice_count * 80)
        if hp_after <= active.hp:
            return True, "no effective healing"
        if hp_after < floor:
            return True, f"even {ice_count}x heal < floor {floor}"
        if hp_after >= ceiling:
            return False, f"use Ice Cream: {ice_count}x heal ({hp_after}) >= ceil {ceiling}"
        return False, f"use Ice Cream: {ice_count}x heal ({hp_after}) between floor={floor} ceil={ceiling}"

    threshold = _IC_HP_THRESHOLD.get(m, 220)
    if active.hp > threshold:
        return True, f"HP {active.hp} > {threshold} ({m})"
    return False, ""


# ── Apply overrides (Crustle-specific) ──────────────────────────────────────
def _apply_overrides(obs, opt, score, reason):
    if opt.type == OptionType.PLAY:
        card = _option_card(obs, opt)
        cid = card.id if card else None
        if _my_state(obs).deckCount <= 10 and cid == EXPLORER:
            return -5000, "hard: don't Explorer with low deck"

    if _detect_matchup(obs) != "crustle":
        return score, reason

    card = _option_card(obs, opt)
    cid = card.id if card else getattr(opt, "cardId", None)

    if opt.type == OptionType.EVOLVE and cid == ARCHALUDON_EX:
        return -10000, "Crustle: don't evolve to ex"

    if opt.type == OptionType.ATTACK:
        aid = getattr(opt, "attackId", None)
        active = _active(obs)
        opp_act = _opp_active(obs)
        opp_has_spiky = bool(
            opp_act
            and any(
                getattr(c, "id", None) == 14
                for c in (getattr(opp_act, "energyCards", None) or [])
            )
        )
        if (
            active
            and active.id == DURALUDON
            and active.hp == 130
            and opp_act
            and opp_act.id == 345
            and _energy_count(opp_act) >= 2
            and opp_has_spiky
        ):
            return -3000, "Crustle: full HP Duraludon waits out Spiky"
        if aid == METAL_DEFENDER:
            return -5000, "Crustle: Metal Defender does 0"
        if aid == RAGING_HAMMER:
            return max(score, 200), "Crustle: Raging Hammer"

    if opt.type == OptionType.PLAY:
        if cid == RELICANTH:
            return -5000, "Crustle: skip Relicanth"
        dc = _my_state(obs).deckCount
        if dc <= 10 and cid in (EXPLORER, LILLIE):
            if cid == LILLIE and dc <= 3 and _my_state(obs).handCount >= dc + 6:
                return 15000, "Crustle: Lillie to refill deck"
            return -5000, "Crustle: don't draw with low deck"

    if opt.type == OptionType.ATTACH:
        target = _option_target(obs, opt)
        tid = target.id if target else None
        if getattr(opt, "inPlayArea", None) == AreaType.BENCH and tid == DURALUDON:
            return score + 10000, "Crustle: bench Duraludon energy priority"

    return score, reason


# ── Setup scoring ─────────────────────────────────────────────────────────────
def _score_setup(obs, opt):
    card = _option_card(obs, opt)
    cid = card.id if card else None
    ctx = obs.select.context
    if ctx == SelectContext.MULLIGAN:
        return (10000, "no mulligan") if opt.type == OptionType.NO else (0, "mulligan")
    if ctx == SelectContext.IS_FIRST:
        return (10000, "choose second") if opt.type == OptionType.NO else (0, "go first")
    if ctx == SelectContext.SETUP_ACTIVE_POKEMON:
        return _SETUP_ACTIVE_PRIORITY.get(cid, (0, "unknown Active"))
    if ctx == SelectContext.SETUP_BENCH_POKEMON:
        return -10000, "never bench during setup"
    return 0, "non-setup"


# ── Play scoring ─────────────────────────────────────────────────────────────
def _score_play(obs, opt):
    card = _option_card(obs, opt)
    cid = card.id if card else None
    ids = _hand_ids(obs)

    if cid in {DURALUDON, RELICANTH}:
        return 18000, "play Pokemon"

    if cid == FULL_METAL_LAB:
        active = _active(obs)
        if active and active.id not in {DURALUDON, ARCHALUDON_EX}:
            return -200, "skip FML: Active not Metal"
        return 20000, "play Full Metal Lab"

    # Items
    if cid in {POKE_PAD, ULTRA_BALL, POKEGEAR, NIGHT_STRETCHER, JUMBO_ICE_CREAM, HERO_CAPE}:
        if cid == HERO_CAPE:
            if not any(p.id in {ARCHALUDON_EX, DURALUDON} and not _has_tool(p) for p in _all_my_pokemon(obs)):
                return -500, "save Hero's Cape: no target"
        if cid == JUMBO_ICE_CREAM:
            active = _active(obs)
            if active:
                skip, _ = _should_skip_ice_cream(obs, active)
                if skip:
                    return -500, "skip Ice Cream"
        if cid == NIGHT_STRETCHER:
            disc = _discard_ids(obs)
            has_urgent = (
                (DURALUDON in disc and DURALUDON not in ids and
                 (sum(1 for p in _all_my_pokemon(obs) if p.id in {DURALUDON, ARCHALUDON_EX}) < 2))
                or (ARCHALUDON_EX in disc and ARCHALUDON_EX not in ids and _has_in_play(obs, DURALUDON))
                or (
                    METAL_ENERGY in disc
                    and not obs.current.energyAttached
                    and METAL_ENERGY not in ids
                    and any(
                        p
                        and p.id in (DURALUDON, ARCHALUDON_EX)
                        and _energy_count(p) == 2
                        for p in _all_my_pokemon(obs)
                    )
                )
            )
            if not has_urgent:
                return -500, "save Night Stretcher"
        if cid == ULTRA_BALL:
            bench_empty = len([p for p in _my_state(obs).bench if p]) == 0
            if bench_empty:
                return 300, "Ultra Ball: bench empty"
            metal_in_hand = sum(1 for c in (_my_state(obs).hand or []) if c and c.id == METAL_ENERGY)
            metal_in_trash = _metal_in_discard(obs)
            if metal_in_trash == 0 and metal_in_hand >= 1:
                return 20000, "Ultra Ball: fuel Alloy"
            return -1000, "skip Ultra Ball"
        return 20000, "play item"

    if cid == EXPLORER:
        if obs.current.supporterPlayed:
            return -1000, "Supporter already used"
        return 16000, "play Explorer"

    if cid == LILLIE:
        if obs.current.supporterPlayed:
            return -1000, "Supporter already used"
        if BOSS in ids and _archaludon_attack_route(obs):
            return -500, "save Lillie: Boss in hand"
        return 5000, "play Lillie"

    if cid == BOSS:
        if obs.current.supporterPlayed:
            return -1000, "Supporter already used"
        m = _detect_matchup(obs)
        if m == "hop":
            active = _active(obs)
            opp_has_snorlax = any(p.id == HOP_SNORLAX for p in (_opp_state(obs).bench or []) if p)
            if opp_has_snorlax and active:
                if active.id == CINDERACE and any(
                    p.id in {DURALUDON, ARCHALUDON_EX} for p in _my_state(obs).bench if p
                ):
                    return 16500, "Boss: pull Snorlax (Cinderace)"
                if active.id == ARCHALUDON_EX and active.hp > 220:
                    route = _archaludon_attack_route(obs)
                    if route:
                        return 16500, "Boss: pull Snorlax (Arch can tank)"
        if _opp_last_attack_id == MEGA_BRAVE:
            return -500, "save Boss: Mega Brave stuck"
        route = _archaludon_attack_route(obs)
        if not route:
            return -500, "save Boss: no attacker"
        opp_act = _opp_active(obs)
        attacks = [{"damage": 220}]
        if _has_in_play(obs, RELICANTH):
            attacks.append({"damage": 80 + _damage_on(route["attacker"]) // 10 * 10})
        can_ko_active = opp_act and any(
            _effective_damage(a["damage"], opp_act) >= opp_act.hp for a in attacks
        )
        remaining = len(_my_state(obs).prize)
        if can_ko_active:
            pv = 2 if CARD_DB.get(opp_act.id) and getattr(CARD_DB[opp_act.id], "ex", False) else 1
            if pv >= remaining:
                return -500, "save Boss: Active KO wins"
            for target in (_opp_state(obs).bench or []):
                if not target:
                    continue
                for atk in attacks:
                    if _effective_damage(atk["damage"], target) >= target.hp:
                        tpv = 2 if CARD_DB.get(target.id) and getattr(CARD_DB[target.id], "ex", False) else 1
                        if tpv >= remaining:
                            return 20000, "LETHAL Boss"
                        break
            return -500, "save Boss: can KO Active"
        return -500, "save Boss"

    return 1000, "generic play"


# ── Evolve scoring ────────────────────────────────────────────────────────────
def _score_evolve(obs, opt):
    card = _option_card(obs, opt)
    target = _option_target(obs, opt)
    cid = card.id if card else None
    tid = target.id if target else None
    if cid == ARCHALUDON_EX and tid == DURALUDON:
        is_active = getattr(opt, "inPlayArea", None) == AreaType.ACTIVE
        mc = _metal_in_discard(obs)
        if is_active:
            if _energy_count(target) >= 3 and not _has_in_play(obs, ARCHALUDON_EX):
                return 17000, "evolve Active 3-energy Duraludon"
            if mc >= 2:
                return 28000 + mc * 2000, "evolve Active Duraludon"
            if mc == 1:
                return 8000, "delay Active evolve: 1 Metal"
            return -500, "hold: no Metal in discard"
        if mc >= 2:
            return 14000 + mc * 1000, "evolve Bench Duraludon"
        return -1000, "hold: evolve Active first"
    return 10000, "generic evolution"


# ── Attach scoring ─────────────────────────────────────────────────────────────
def _attach_target_score(obs, target, area):
    if target is None:
        return 0
    cid = target.id
    e = _energy_count(target)
    if e >= 3:
        return -5000
    if cid == CINDERACE and e >= 1:
        return -3000
    score = 0
    if cid == CINDERACE:
        score = 3000 + (7000 if e == 0 else 0) + (12000 if area == AreaType.ACTIVE else 5000)
    elif cid in {DURALUDON, ARCHALUDON_EX}:
        score = 6000 if cid == ARCHALUDON_EX else 5500
        score += {2: 12000, 1: 7000, 0: 4000}.get(e, -1000)
        score += 1000 if area == AreaType.ACTIVE else 500
    else:
        score = 1000
    return score


def _score_attach(obs, opt):
    card = _option_card(obs, opt)
    target = _option_target(obs, opt)
    cid = card.id if card else None
    tid = target.id if target else None
    if cid == HERO_CAPE:
        if tid == ARCHALUDON_EX and target and not _has_tool(target):
            return 11000, "Hero's Cape on Archaludon ex"
        if tid == DURALUDON and target and not _has_tool(target) and _energy_count(target) >= 1:
            return 8000, "Hero's Cape on Duraludon"
        return -1000, "save Hero's Cape"
    if cid != METAL_ENERGY:
        return -500, "skip non-Metal"
    if obs.current.energyAttached:
        return -1000, "already attached"
    return _attach_target_score(obs, target, getattr(opt, "inPlayArea", None)), "attach Metal"


# ── Retreat scoring ───────────────────────────────────────────────────────────
def _score_retreat(obs, opt):
    active = _active(obs)
    if active and active.id == ARCHALUDON_EX and _has_tool(active) and active.hp > 200:
        return -5000, "don't retreat HP400 tank"
    route = _archaludon_attack_route(obs)
    if route and route["needs_retreat"]:
        return 13000, "retreat to attack-ready ex"
    return -100, "avoid retreat"


# ── Target/to-hand/discard scoring ────────────────────────────────────────────
def _score_to_hand(obs, opt):
    card = _option_card(obs, opt)
    cid = card.id if card else getattr(opt, "cardId", None)
    ids = _hand_ids(obs)
    effect = getattr(obs.select, "effect", None)
    effect_id = effect.id if effect else None

    if effect_id == EXPLORER:
        metal_in_hand = sum(1 for c in (_my_state(obs).hand or []) if c and c.id == METAL_ENERGY)
        if cid == HERO_CAPE:
            has_target = any(p.id == ARCHALUDON_EX and not _has_tool(p) for p in _all_my_pokemon(obs))
            return (27000 if has_target else 22000), "Explorer: Hero's Cape"
        if cid == METAL_ENERGY:
            if metal_in_hand > 0:
                return 0, "Explorer: skip energy"
            return 25000, "Explorer: take 1st energy"
        if cid == ARCHALUDON_EX and not _has_in_play(obs, ARCHALUDON_EX):
            return 20000, "Explorer: take Archaludon ex"
        if cid == DURALUDON and not _has_in_play(obs, DURALUDON):
            return 18000, "Explorer: take Duraludon"
        if cid == RELICANTH and not _has_in_play(obs, RELICANTH) and RELICANTH not in ids:
            return 15000, "Explorer: take Relicanth"
        if cid in (EXPLORER, LILLIE):
            sup_count = sum(1 for c in (_my_state(obs).hand or []) if c and c.id in (EXPLORER, LILLIE))
            if sup_count == 0:
                return 12000, "Explorer: take supporter"
        return 0, "Explorer: let discard"

    if cid == DURALUDON and DURALUDON not in ids:
        return 22000, "take Duraludon"
    if cid == ARCHALUDON_EX and ARCHALUDON_EX not in ids:
        return 20000, "take Archaludon ex"
    if cid == CINDERACE:
        return -2000, "skip Cinderace"
    if cid == RELICANTH and not _has_in_play(obs, RELICANTH):
        return 9000, "take Relicanth"
    if cid == METAL_ENERGY:
        return 8000, "take Metal Energy"
    if cid == HERO_CAPE:
        has_target = any(p.id == ARCHALUDON_EX and not _has_tool(p) for p in _all_my_pokemon(obs))
        return (6000 if has_target else 1000), "take Hero's Cape"
    if cid == FULL_METAL_LAB:
        return 5000, "take Full Metal Lab"
    if cid == BOSS:
        return 2500, "take Boss"
    return 1000, "generic take"


def _score_discard(obs, opt):
    card = _option_card(obs, opt)
    cid = card.id if card else getattr(opt, "cardId", None)
    ids = _hand_ids(obs)
    mc = _metal_in_discard(obs)
    if cid == METAL_ENERGY:
        if mc < 2:
            return 15000, "discard Metal"
        return (12000 if ids.count(METAL_ENERGY) > 1 else -1000), "discard Metal"
    if cid == CINDERACE:
        return 10000, "discard Cinderace"
    if cid in {BOSS, FULL_METAL_LAB, POKEGEAR}:
        return 8500, "discard utility"
    if cid in {LILLIE, EXPLORER} and ids.count(cid) > 1:
        return 8000, "discard duplicate supporter"
    if cid == RELICANTH and (_has_in_play(obs, RELICANTH) or ids.count(RELICANTH) > 1):
        return 6500, "discard extra Relicanth"
    if cid == ARCHALUDON_EX:
        return -5000, "keep Archaludon ex"
    if cid == DURALUDON:
        return -4000, "keep Duraludon"
    return 1000, "generic discard"


def _score_target(obs, opt):
    card = _option_card(obs, opt)
    cid = card.id if card else getattr(opt, "cardId", None)
    ctx = obs.select.context
    if ctx == SelectContext.ATTACH_TO:
        return (5000, "Metal") if cid == METAL_ENERGY else (1000, "attach")
    if ctx in {SelectContext.TO_FIELD, SelectContext.TO_BENCH}:
        if cid == ARCHALUDON_EX:
            return 18000, "target Archaludon ex"
        if cid == DURALUDON:
            return 16000, "target Duraludon"
        if cid == CINDERACE:
            return 3000, "avoid Cinderace"
    if ctx == SelectContext.HEAL:
        return (20000 + _damage_on(card), "heal Archaludon ex") if cid == ARCHALUDON_EX else (_damage_on(card), "heal")
    if ctx in {SelectContext.SWITCH, SelectContext.TO_ACTIVE}:
        yi = obs.current.yourIndex
        pi = getattr(opt, "playerIndex", yi)
        if pi != yi and card:
            if _detect_matchup(obs) == "hop" and cid == HOP_SNORLAX:
                active = _active(obs)
                e = _energy_count(card)
                if active and active.id == CINDERACE:
                    return 30000 - e * 100 + card.hp, "Boss: Snorlax (Cinderace)"
                else:
                    return 30000 + e * 100 + card.hp, "Boss: Snorlax (Arch)"
            pv = 2 if CARD_DB.get(cid) and getattr(CARD_DB[cid], "ex", False) else 1
            te = _energy_count(card)
            route = _archaludon_attack_route(obs)
            killable = route and any(
                _effective_damage(a["damage"], card) >= card.hp for a in [{"damage": 220}]
            )
            if killable:
                return 20000 + pv * 3000 + te * 100, "Boss: KO"
            return 5000 + pv * 1000 + te * 200, "Boss: drag"
        if cid == CINDERACE:
            return 16000, "promote Cinderace"
        if cid == ARCHALUDON_EX:
            return 15000, "promote Archaludon ex"
        if cid == DURALUDON:
            return 8000, "promote Duraludon"
    if ctx == SelectContext.DAMAGE:
        hp = getattr(card, "hp", 999) if card else 999
        return 10000 - hp, "damage: lowest HP"
    return 1000, "generic target"


# ── Score dispatcher ──────────────────────────────────────────────────────────
_MAIN_DISPATCH = {
    OptionType.PLAY: _score_play,
    OptionType.EVOLVE: _score_evolve,
    OptionType.ATTACH: _score_attach,
    OptionType.RETREAT: _score_retreat,
}


def _score_option(obs, opt):
    ctx = obs.select.context

    if ctx in {SelectContext.IS_FIRST, SelectContext.MULLIGAN,
               SelectContext.SETUP_ACTIVE_POKEMON, SelectContext.SETUP_BENCH_POKEMON}:
        return _score_setup(obs, opt)

    if opt.type in {OptionType.YES, OptionType.NO}:
        if ctx == SelectContext.IS_FIRST:
            return _score_setup(obs, opt)
        if ctx == SelectContext.ACTIVATE:
            return (100000, "Explosiveness") if opt.type == OptionType.YES else (-100000, "never decline")
        return (1, "yes") if opt.type == OptionType.YES else (0, "no")

    if opt.type == OptionType.NUMBER:
        return (getattr(opt, "number", 0) or 0), "number"

    if ctx == SelectContext.MAIN:
        fn = _MAIN_DISPATCH.get(opt.type)
        if fn:
            score, reason = fn(obs, opt)
        elif opt.type == OptionType.ABILITY:
            score, reason = 1, "ability"
        elif opt.type == OptionType.ATTACK:
            score, reason = _best_attack_damage(obs, getattr(opt, "attackId", 0)), "attack"
        elif opt.type == OptionType.END:
            score, reason = 0, "end turn"
        else:
            score, reason = 500, "generic MAIN"
    elif ctx == SelectContext.TO_HAND:
        score, reason = _score_to_hand(obs, opt)
    elif ctx in {SelectContext.DISCARD, SelectContext.DISCARD_CARD_OR_ATTACHED_CARD}:
        score, reason = _score_discard(obs, opt)
    elif ctx in {SelectContext.ATTACH_TO, SelectContext.TO_FIELD, SelectContext.TO_BENCH,
                 SelectContext.ATTACH_FROM, SelectContext.SWITCH, SelectContext.TO_ACTIVE,
                 SelectContext.HEAL, SelectContext.DAMAGE}:
        score, reason = _score_target(obs, opt)
    elif ctx == SelectContext.ATTACK:
        score, reason = _best_attack_damage(obs, getattr(opt, "attackId", 0)), "attack"
    elif opt.type == OptionType.CARD:
        score, reason = _score_to_hand(obs, opt)
    elif opt.type == OptionType.ENERGY:
        score, reason = 1000, "energy"
    elif opt.type == OptionType.END:
        score, reason = 0, "end"
    else:
        score, reason = 100, "fallback"

    return _apply_overrides(obs, opt, score, reason)


# ── Choose ───────────────────────────────────────────────────────────────────
def _choose_options(obs):
    scored = []
    for i, opt in enumerate(obs.select.option):
        try:
            score, reason = _score_option(obs, opt)
        except Exception:
            score, reason = -999999, "score error"
        scored.append((score, i, reason))
    scored.sort(key=lambda x: (x[0], -x[1]), reverse=True)

    selected = []
    for score, i, _ in scored:
        if len(selected) >= obs.select.maxCount:
            break
        if score < 0 and len(selected) >= obs.select.minCount:
            continue
        selected.append(i)
    if len(selected) < obs.select.minCount:
        selected = [i for _, i, _ in scored[: obs.select.minCount]]
    return selected


# ── Optional beam search (Kaggle-safe) ────────────────────────────────────────
import time as _time

_SEARCH_OK = False
try:
    from cg.api import search_begin, search_step, search_end  # type: ignore
    _SEARCH_OK = True
except Exception:
    _SEARCH_OK = False

ENABLE_SEARCH = True
CAND = 6
MAXD = 40
MARGIN = 4000.0
BUDGET = 2.0
_MAIN_CTX = SelectContext.MAIN


def _evaluate_state(obs, me):
    st = obs.current
    if st is None:
        return 0.0
    mp = st.players[me]
    op = st.players[1 - me]
    if len(mp.prize) == 0:
        return 9e6
    if len(op.prize) == 0:
        return -9e6
    val = (len(op.prize) - len(mp.prize)) * 10000.0
    for p in ([mp.active[0]] if mp.active else []) + list(mp.bench):
        if p is None:
            continue
        val += _energy_count(p) * 200.0
        if p.id == ARCHALUDON_EX:
            val += 500.0
        elif p.id == DURALUDON:
            val += 200.0
    if mp.active and mp.active[0]:
        a = mp.active[0]
        val += a.hp * 2.0
        if a.id == ARCHALUDON_EX and _energy_count(a) >= 3:
            val += 800.0
    if op.active and op.active[0]:
        val -= op.active[0].hp * 2.5
    val += getattr(mp, "handCount", 0) * 10.0
    if getattr(mp, "deckCount", 60) < 5:
        val -= 5000.0
    return val


def _ranked(obs):
    scored = []
    for i, opt in enumerate(obs.select.option):
        try:
            s, _ = _score_option(obs, opt)
        except Exception:
            s = -1e9
        scored.append((s, i))
    scored.sort(key=lambda x: (x[0], -x[1]), reverse=True)
    return [i for _, i in scored]


def _rollout(sid, obs, me):
    cur_obs = obs
    depth = 0
    start_turn = cur_obs.current.turn
    while (
        cur_obs.select is not None
        and cur_obs.current.result is not None
        and cur_obs.current.result == -1
        and cur_obs.current.yourIndex == me
        and cur_obs.current.turn == start_turn
        and depth < MAXD
    ):
        try:
            act = _choose_options(cur_obs)
        except Exception:
            break
        try:
            ar = search_step(sid, act)
        except Exception:
            break
        if getattr(ar, "error", 0) != 0 or ar.state is None:
            break
        cur_obs = ar.state.observation
        sid = ar.state.searchId
        depth += 1
    return cur_obs


def _line_value(cur, me, endobs):
    if cur.result == me:
        return (2, 6, 9e6)
    if cur.result == (1 - me):
        return (-1, 0, -9e6)
    prizes = 6 - len(cur.players[me].prize)
    return (0, prizes, _evaluate_state(endobs, me))


def _search_choose(obs_dict, obs):
    sbi = obs_dict.get("search_begin_input") or getattr(obs, "search_begin_input", None)
    if not sbi:
        return None
    heur = _choose_options(obs)
    hidx = heur[0] if heur else 0
    res = search_begin(sbi)
    if getattr(res, "error", 0) != 0 or getattr(res, "state", None) is None:
        return None
    root_sid = res.state.searchId
    me = obs.current.yourIndex
    order = _ranked(obs)
    cands = []
    for i in list(order[:CAND]) + [hidx]:
        if i not in cands:
            cands.append(i)
    vals = {}
    t0 = _time.time()
    for i in cands:
        if _time.time() - t0 > BUDGET:
            break
        try:
            ar = search_step(root_sid, [i])
        except Exception:
            continue
        if getattr(ar, "error", 0) != 0 or ar.state is None:
            continue
        endobs = _rollout(ar.state.searchId, ar.state.observation, me)
        vals[i] = _line_value(endobs.current, me, endobs)
    try:
        search_end()
    except Exception:
        pass
    if not vals:
        return None
    h = vals.get(hidx, (0, 0, -1e18))
    bp = max(vals, key=lambda i: (vals[i][0], vals[i][1]))
    if (vals[bp][0], vals[bp][1]) > (h[0], h[1]):
        return [bp]
    be = max(vals, key=lambda i: vals[i][2])
    if vals[be][2] > h[2] + MARGIN and (vals[be][0], vals[be][1]) >= (h[0], h[1]):
        return [be]
    return heur


# ── agent() — Kaggle entry point ──────────────────────────────────────────────
def agent(obs_dict: dict) -> list:
    """
    Called by the Kaggle engine for every decision.
    Step 0 (deck selection): returns the 60-card deck list.
    Subsequent steps: returns action indices satisfying obs.select.minCount/maxCount.
    """
    # ── Deck selection phase ──────────────────────────────────────────────────
    if obs_dict.get("select") is None:
        return DECK

    if not _CG_OK:
        sel = obs_dict.get("select") or {}
        opts = sel.get("option") or []
        mx = (sel.get("maxCount") or 1) if sel.get("maxCount") is not None else 1
        n = len(opts)
        return list(range(min(mx, n) if n > 0 else 0))

    try:
        obs = to_observation_class(obs_dict)
    except Exception:
        sel = obs_dict.get("select") or {}
        opts = sel.get("option") or []
        mx = (sel.get("maxCount") or 1) if sel.get("maxCount") is not None else 1
        n = len(opts)
        return list(range(min(mx, n) if n > 0 else 0))

    if obs.select is None:
        return DECK

    try:
        _update_opp_attack_tracking(obs)
    except Exception:
        pass

    if not obs.select.option:
        return []

    sel = obs.select
    if (
        _SEARCH_OK
        and ENABLE_SEARCH
        and sel.context == _MAIN_CTX
        and sel.minCount == 1
        and sel.maxCount == 1
        and len(sel.option) >= 2
    ):
        try:
            r = _search_choose(obs_dict, obs)
            if r:
                return r
        except Exception:
            pass

    try:
        return _choose_options(obs)
    except Exception:
        mx = getattr(sel, "maxCount", 1) or 1
        return list(range(min(mx, len(sel.option))))
